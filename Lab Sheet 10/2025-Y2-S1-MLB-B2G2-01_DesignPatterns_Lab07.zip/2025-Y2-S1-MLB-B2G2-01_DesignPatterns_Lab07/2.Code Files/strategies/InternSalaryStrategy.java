package com.example.employee_management_system.strategy;

import com.example.employee_management_system.entity.Employee;
import java.math.BigDecimal;

public class InternSalaryStrategy implements SalaryStrategy {
    @Override
    public BigDecimal calculateSalary(Employee employee) {
        // Fixed allowance
        return BigDecimal.valueOf(15000);
    }
}
