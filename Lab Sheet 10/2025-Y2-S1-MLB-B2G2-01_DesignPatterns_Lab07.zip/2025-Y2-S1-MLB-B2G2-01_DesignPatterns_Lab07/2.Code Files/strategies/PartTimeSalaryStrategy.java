package com.example.employee_management_system.strategy;

import com.example.employee_management_system.entity.Employee;
import java.math.BigDecimal;

public class PartTimeSalaryStrategy implements SalaryStrategy {

    @Override
    public BigDecimal calculateSalary(Employee employee) {
        // Assume employee.getSalary() returns a Double hourly rate
        // and employee.getHoursWorked() returns a Double for hours

        Double hourlyRate = employee.getSalary();     // e.g., 1500.0
        Double hoursWorked = employee.getHoursWorked(); // e.g., 40.0

        // Safely handle null values
        if (hourlyRate == null || hoursWorked == null) {
            return BigDecimal.ZERO;
        }

        // Convert both to BigDecimal for proper arithmetic
        BigDecimal rate = BigDecimal.valueOf(hourlyRate);
        BigDecimal hours = BigDecimal.valueOf(hoursWorked);

        // Multiply for total salary
        return rate.multiply(hours);
    }
}
