package com.example.employee_management_system.strategy;

import com.example.employee_management_system.entity.Employee;
import java.math.BigDecimal;

public class FullTimeSalaryStrategy implements SalaryStrategy {

    @Override
    public BigDecimal calculateSalary(Employee employee) {
        // Assume base salary (monthly) is stored as Double
        Double baseSalary = employee.getSalary(); // e.g., 120000.0

        // Safely handle null
        if (baseSalary == null) {
            return BigDecimal.ZERO;
        }

        // Convert to BigDecimal
        BigDecimal salary = BigDecimal.valueOf(baseSalary);

        // Apply any full-time benefits or bonuses
        // Example: 10% bonus for full-time employees
        BigDecimal bonus = salary.multiply(BigDecimal.valueOf(0.10));

        // Return total = base + bonus
        return salary.add(bonus);
    }
}
