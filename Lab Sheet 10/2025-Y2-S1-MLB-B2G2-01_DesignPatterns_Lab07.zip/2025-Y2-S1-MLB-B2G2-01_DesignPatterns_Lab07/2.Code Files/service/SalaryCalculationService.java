package com.example.employee_management_system.service;

import com.example.employee_management_system.entity.Employee;
import com.example.employee_management_system.strategy.*;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;

@Service
public class SalaryCalculationService {

    public BigDecimal calculate(Employee employee) {
        SalaryContext context = new SalaryContext();

        switch (employee.getJobType().toLowerCase()) {
            case "fulltime" -> context.setStrategy(new FullTimeSalaryStrategy());
            case "parttime" -> context.setStrategy(new PartTimeSalaryStrategy());
            case "intern" -> context.setStrategy(new InternSalaryStrategy());
            default -> throw new IllegalArgumentException("Unknown employee type: " + employee.getJobType());
        }

        return context.executeStrategy(employee);
    }
}
