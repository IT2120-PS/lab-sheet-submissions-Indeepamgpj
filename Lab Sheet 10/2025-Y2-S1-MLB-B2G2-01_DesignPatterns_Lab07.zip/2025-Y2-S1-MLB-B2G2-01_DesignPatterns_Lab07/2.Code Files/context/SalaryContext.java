package com.example.employee_management_system.strategy;

import com.example.employee_management_system.entity.Employee;
import java.math.BigDecimal;

public class SalaryContext {
    private SalaryStrategy strategy;

    public void setStrategy(SalaryStrategy strategy) {
        this.strategy = strategy;
    }

    public BigDecimal executeStrategy(Employee employee) {
        return strategy.calculateSalary(employee);
    }
}
