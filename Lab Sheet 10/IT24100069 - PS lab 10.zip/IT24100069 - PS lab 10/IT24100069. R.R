setwd ("C:\\Users\\USER\\Desktop\\IT24100069 - PS lab 10")
data <- read.csv("Data.csv")
View(data)
str(data)

#1
customers <- c(55, 62, 43, 46, 50)
days <- c("Mon", "Tue", "Wed", "Thu", "Fri")
result1 <- chisq.test(customers, p = rep(1/5, 5))
print(result1)
result1$expected

#2
tasks <- read.csv("C:\\Users\\USER\\Desktop\\IT24100069 - PS lab 10\\Data.csv", row.names = 1)
View(tasks)
result2 <- chisq.test(tasks)
print(result2)
result2$expected

#3
snack_counts <- c(45, 39, 33, 43)   # Replace with your actual data if in CSV
snack_types <- c("A", "B", "C", "D")
result3 <- chisq.test(snack_counts, p = rep(1/4, 4))
print(result3)
result3$expected
sink("ChiSquare_Lab10_Output.txt")
cat("=== Question 1: Shop Owner Test ===\n")
print(result1)
cat("\n=== Question 2: House Tasks Test ===\n")
print(result2)
cat("\n=== Question 3: Vending Machine Test ===\n")
print(result3)
sink()